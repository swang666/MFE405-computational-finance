// readme
// author: Sumeng Wang

run project1.cpp to calculate each question the 
homework specifies. It also generates 3 csv files:
ques2.csv, ques3.csv, ques4.csv for plotting histograms.

run project1.rmd to generate histograms and the pdf
of the report.

All csv files and pdf are already included.